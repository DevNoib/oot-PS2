    {
        CAM_SET_NONE, // setting
        0, // count
        NULL, // bgCamFuncData
    }, // 0

