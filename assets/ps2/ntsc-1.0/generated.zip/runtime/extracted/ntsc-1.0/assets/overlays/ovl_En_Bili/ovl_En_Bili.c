#include "ovl_En_Bili.h"

#include "sys_matrix.h"

static Gfx D_809C16F0[2] = {
#include "assets/overlays/ovl_En_Bili/D_809C16F0.inc.c"
};

static Gfx D_809C1700[2] = {
#include "assets/overlays/ovl_En_Bili/D_809C1700.inc.c"
};

